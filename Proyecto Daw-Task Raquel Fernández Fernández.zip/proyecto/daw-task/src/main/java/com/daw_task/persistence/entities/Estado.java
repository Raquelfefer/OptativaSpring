package com.daw_task.persistence.entities;

public enum Estado {

	PENDIENTE, EN_PROGRESO, COMPLETADA;
}
