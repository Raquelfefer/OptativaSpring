package com.daw_task.services.exceptions;

public class TareaException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public TareaException(String message) {
		super(message);
	}
}
