-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Servidor: db:3306
-- Tiempo de generación: 20-10-2025 a las 19:33:45
-- Versión del servidor: 10.3.39-MariaDB-1:10.3.39+maria~ubu2004
-- Versión de PHP: 8.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `daw-task`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarea`
--

CREATE TABLE `tarea` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `fecha_creacion` date NOT NULL,
  `fecha_vencimiento` date NOT NULL,
  `estado` enum('PENDIENTE','EN_PROGRESO','COMPLETADA') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `tarea`
--

INSERT INTO `tarea` (`id`, `titulo`, `descripcion`, `fecha_creacion`, `fecha_vencimiento`, `estado`) VALUES
(1, 'Comprar suministros', 'Comprar comida y medicamentos para el refugio', '2025-10-01', '2025-10-05', 'PENDIENTE'),
(2, 'Revisar animales', 'Inspección sanitaria mensual de los animales en el matadero', '2025-10-10', '2025-10-12', 'EN_PROGRESO'),
(3, 'Actualizar software', 'Actualizar la aplicación web con nuevas funciones', '2025-09-20', '2025-10-02', 'COMPLETADA'),
(4, 'Planificar evento', 'Organizar la jornada de adopción de perros y gatos', '2025-10-15', '2025-10-18', 'PENDIENTE'),
(5, 'Formación continua', 'Curso online sobre nuevas normativas veterinarias', '2025-10-05', '2025-10-20', 'EN_PROGRESO'),
(6, 'Revisión de corrales', 'Inspeccionar las condiciones higiénicas de los corrales antes del sacrificio.', '2025-10-20', '2025-10-21', 'PENDIENTE'),
(7, 'Vacunación de ganado bovino', 'Aplicar la vacuna antibrucélica a 25 reses.', '2025-10-18', '2025-10-22', 'EN_PROGRESO'),
(8, 'Control de temperaturas en cámaras', 'Verificar el correcto funcionamiento de las cámaras frigoríficas del matadero.', '2025-10-19', '2025-10-20', 'COMPLETADA'),
(9, 'Revisión de documentación sanitaria', 'Comprobar los certificados de origen y guías de transporte animal.', '2025-10-20', '2025-10-23', 'PENDIENTE'),
(10, 'Toma de muestras de agua', 'Recoger y enviar muestras al laboratorio para control microbiológico.', '2025-10-17', '2025-10-21', 'EN_PROGRESO'),
(11, 'Supervisión de limpieza post-faena', 'Asegurar la correcta desinfección de utensilios y áreas de trabajo.', '2025-10-19', '2025-10-20', 'COMPLETADA'),
(12, 'Control de bienestar animal', 'Evaluar si se cumplen las normativas de bienestar durante el aturdimiento.', '2025-10-20', '2025-10-21', 'PENDIENTE'),
(13, 'Revisión de registros de medicamentos', 'Auditar fichas de tratamientos en animales de abasto.', '2025-10-15', '2025-10-20', 'COMPLETADA'),
(14, 'Identificación de canales', 'Verificar la correcta trazabilidad de las canales marcadas.', '2025-10-18', '2025-10-22', 'EN_PROGRESO'),
(15, 'Informe semanal de inspección', 'Redactar informe con hallazgos y observaciones de la semana.', '2025-10-20', '2025-10-24', 'PENDIENTE');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tarea`
--
ALTER TABLE `tarea`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tarea`
--
ALTER TABLE `tarea`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
