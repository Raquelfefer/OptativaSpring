-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Servidor: db:3306
-- Tiempo de generación: 27-10-2025 a las 19:52:23
-- Versión del servidor: 10.3.39-MariaDB-1:10.3.39+maria~ubu2004
-- Versión de PHP: 8.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pokedaw`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pokemon`
--

CREATE TABLE `pokemon` (
  `id` int(11) NOT NULL,
  `capturado` enum('POKEBALL','SUPERBALL','ULTRABALL') DEFAULT NULL,
  `fecha_captura` date DEFAULT NULL,
  `numero_pokedex` int(11) DEFAULT NULL,
  `tipo1` enum('AGUA','BICHO','DRAGON','ELECTRICO','FANTASMA','FUEGO','HIELO','LUCHA','NINGUNO','NORMAL','PLANTA','PSIQUICO','ROCA','TIERRA','VENENO','VOLADOR') DEFAULT NULL,
  `tipo2` enum('AGUA','BICHO','DRAGON','ELECTRICO','FANTASMA','FUEGO','HIELO','LUCHA','NINGUNO','NORMAL','PLANTA','PSIQUICO','ROCA','TIERRA','VENENO','VOLADOR') DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `pokemon`
--

INSERT INTO `pokemon` (`id`, `capturado`, `fecha_captura`, `numero_pokedex`, `tipo1`, `tipo2`, `nombre`) VALUES
(1, 'POKEBALL', '2024-03-15', 1, 'PLANTA', 'VENENO', 'Bulbasaur'),
(2, 'SUPERBALL', '2024-04-02', 4, 'FUEGO', 'NINGUNO', 'Charmander'),
(3, 'ULTRABALL', '2024-05-10', 7, 'AGUA', 'NINGUNO', 'Squirtle'),
(4, 'POKEBALL', '2024-06-01', 10, 'BICHO', 'NINGUNO', 'Caterpie'),
(5, 'POKEBALL', '2024-06-20', 16, 'NORMAL', 'VOLADOR', 'Pidgey'),
(6, 'SUPERBALL', '2024-07-03', 25, 'ELECTRICO', 'NINGUNO', 'Pikachu'),
(7, 'POKEBALL', '2024-07-25', 37, 'FUEGO', 'NINGUNO', 'Vulpix'),
(8, 'ULTRABALL', '2024-08-12', 54, 'AGUA', 'NINGUNO', 'Psyduck'),
(9, 'SUPERBALL', '2024-09-05', 66, 'FANTASMA', 'NINGUNO', 'Machop'),
(10, 'POKEBALL', '2024-09-22', 74, 'ROCA', 'TIERRA', 'Geodude'),
(12, 'ULTRABALL', '2025-10-26', 90, 'FANTASMA', 'VENENO', 'Gasly');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pokemon`
--
ALTER TABLE `pokemon`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pokemon`
--
ALTER TABLE `pokemon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
