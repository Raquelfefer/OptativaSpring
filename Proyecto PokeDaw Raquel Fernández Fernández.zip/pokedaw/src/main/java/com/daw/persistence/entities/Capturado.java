package com.daw.persistence.entities;

public enum Capturado {
	
	POKEBALL, SUPERBALL, ULTRABALL;
}
