package com.daw.persistence.entities;

public enum Tipo {
	
	BICHO, DRAGON, ELECTRICO, LUCHA, FUEGO, VOLADOR, FANTASMA, PLANTA, TIERRA, HIELO, NORMAL, VENENO, PSIQUICO, ROCA, AGUA, NINGUNO;
}
