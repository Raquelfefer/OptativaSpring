package com.registro.services.exceptions;

public class RegistroException extends RuntimeException{

	 private static final long serialVersionUID = 1L;


	    public RegistroException(String message) {
	        super(message);
	    }

}
