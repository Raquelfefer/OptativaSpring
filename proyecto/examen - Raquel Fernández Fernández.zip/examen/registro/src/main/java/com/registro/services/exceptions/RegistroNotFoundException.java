package com.registro.services.exceptions;

public class RegistroNotFoundException extends RuntimeException{

	 private static final long serialVersionUID = 1L;


	    public RegistroNotFoundException(String message) {
	        super(message);
	    }

}