package com.registro.web.controllers;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.registro.persistence.entities.Registro;
import com.registro.services.RegistroService;
import com.registro.services.exceptions.RegistroException;
import com.registro.services.exceptions.RegistroNotFoundException;

@RestController
@RequestMapping("/registro")
public class RegistroContollers {

	@Autowired
	private RegistroService registroservice;
	
	//Obtener todos los registros
	@GetMapping
	public ResponseEntity<?> findAll(){
		return ResponseEntity.ok(this.registroservice.findAll());
	}
	
	//Obtener un registro por id
	@GetMapping("/{idRegistro}")
	public ResponseEntity<?> findByIDd(@PathVariable int idRegistro){
		try {
			return ResponseEntity.ok(this.registroservice.findById(idRegistro));
		}catch(RegistroNotFoundException ex) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
		}
	}
	
	//Modificar un registro mediante su ID
	@PutMapping("/{idRegistro}")
	public ResponseEntity<?> update(@RequestBody Registro registro, @PathVariable int idRegistro){
		try {
			return ResponseEntity.ok(this.registroservice.update(registro, idRegistro));
		}catch(RegistroNotFoundException ex) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
		}
	}
	
	//Modificar una precipitacion asociada
	@PutMapping("/{idRegistro}")
	public ResponseEntity<?> updatePrecipitacion(@PathVariable int idRegistro, @RequestParam double precipitaconVieja, @RequestParam double precipitacionNueva){
		try {
			return ResponseEntity.ok(this.registroservice.updatePrecipitacion(idRegistro, precipitacionNueva, precipitacionNueva));
		}catch(RegistroNotFoundException ex) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
		}catch(RegistroException ex) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
		}
	}
	
	//Mostrar los registros por ubicacion y rango de fechas
	@GetMapping("/buscar")
	public ResponseEntity<?> findByUbicacionAndFecha(@RequestParam String ubicacion, @RequestParam LocalDate fechaInicio, @RequestParam LocalDate fechaFin){
		return ResponseEntity.ok(this.registroservice.findByUbicacionAndFecha(ubicacion, fechaInicio, fechaFin));
	}
}
