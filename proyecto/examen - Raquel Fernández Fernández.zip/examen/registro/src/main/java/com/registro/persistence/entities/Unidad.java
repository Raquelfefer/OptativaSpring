package com.registro.persistence.entities;

public enum Unidad {

	CELSIUS, FAHRENHEIT;
}
